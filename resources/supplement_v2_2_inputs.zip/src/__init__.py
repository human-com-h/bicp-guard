"""ETCIM research implementation."""
